import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import com.example.testnews.Data.Remote.ApiClient
import com.example.testnews.Data.Response.NewsResponse
import com.example.testnews.R
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ApiClient.create().getNews().enqueue(object : Callback<NewsResponse> {
            override fun onResponse(
                call: Call<NewsResponse>,
                response: Response<NewsResponse>
            ) {
                Log.d("MainActivity", response.body().toString())
            }

            override fun onFailure(call: Call<NewsResponse>, t: Throwable) {
                // Tangani jika terjadi kesalahan saat melakukan request ke API
            }
        })
    }
}
